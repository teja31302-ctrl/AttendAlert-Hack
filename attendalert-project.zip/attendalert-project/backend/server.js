const express = require('express');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

// In-memory seed data for students and subjects
let students = [
  { id: 1, name: 'Rahul Verma', subject: 'Data Structures', totalClasses: 40, attendedClasses: 25 }, // 62.5% (Critical)
  { id: 2, name: 'Priya Sharma', subject: 'Data Structures', totalClasses: 40, attendedClasses: 32 }, // 80% (Safe)
  { id: 3, name: 'Amit Kumar', subject: 'Algorithms', totalClasses: 30, attendedClasses: 21 }, // 70% (Warning)
  { id: 4, name: 'Sneha Reddy', subject: 'Database Systems', totalClasses: 35, attendedClasses: 30 }, // 85.7% (Safe)
  { id: 5, name: 'Vikram Singh', subject: 'Operating Systems', totalClasses: 32, attendedClasses: 19 }, // 59.38% (Critical)
  { id: 6, name: 'Ananya Das', subject: 'Computer Networks', totalClasses: 28, attendedClasses: 20 } // 71.43% (Warning)
];

// Helper function to calculate risk tier and recovery classes
function calculateAttendanceStats(total, attended) {
  const percentage = total === 0 ? 0 : Number(((attended / total) * 100).toFixed(2));
  
  let riskTier = 'Safe';
  if (percentage < 65) {
    riskTier = 'Critical';
  } else if (percentage >= 65 && percentage < 75) {
    riskTier = 'Warning';
  }

  // Recovery formula: ceil((0.75 * Total - Attended) / 0.25)
  let classesNeeded = 0;
  if (percentage < 75) {
    classesNeeded = Math.ceil((0.75 * total - attended) / 0.25);
  }

  return { percentage, riskTier, classesNeeded };
}

// GET all students with computed stats
app.get('/api/students', (req, res) => {
  const enhancedStudents = students.map(s => ({
    ...s,
    ...calculateAttendanceStats(s.totalClasses, s.attendedClasses)
  }));
  res.json(enhancedStudents);
});

// POST to update or log attendance
app.post('/api/attendance', (req, res) => {
  const { id, status } = req.body; // status: 'Present', 'Absent', 'Late'
  const student = students.find(s => s.id === id);
  
  if (!student) {
    return res.status(404).json({ error: 'Student not found' });
  }

  student.totalClasses += 1;
  if (status === 'Present' || status === 'Late') {
    student.attendedClasses += 1;
  }

  const updatedStats = calculateAttendanceStats(student.totalClasses, student.attendedClasses);
  res.json({ success: true, student: { ...student, ...updatedStats } });
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`AttendAlert backend running on port ${PORT}`);
});
