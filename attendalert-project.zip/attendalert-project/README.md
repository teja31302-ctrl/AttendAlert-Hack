# AttendAlert - Attendance Tracking & Early-Warning System

## Setup & Running Instructions

### 1. Start the Backend
```bash
cd backend
npm install
npm start
```
The Express server will run on `http://localhost:5000`.

### 2. Start the Frontend
```bash
cd frontend
npm install
npm start
```
The React application will open on `http://localhost:3000`.
