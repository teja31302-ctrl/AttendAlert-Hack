import React, { useState, useEffect } from 'react';

export default function App() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const res = await fetch('http://localhost:5000/api/students');
      const data = await res.json();
      setStudents(data);
    } catch (err) {
      console.error('Failed to fetch students', err);
    }
  };

  const markAttendance = async (id, status) => {
    try {
      const res = await fetch('http://localhost:5000/api/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status })
      });
      const data = await res.json();
      if (data.success) {
        fetchStudents();
      }
    } catch (err) {
      console.error('Failed to update attendance', err);
    }
  };

  const criticalCount = students.filter(s => s.riskTier === 'Critical').length;
  const warningCount = students.filter(s => s.riskTier === 'Warning').length;

  return (
    <div className="min-h-screen bg-gray-50 p-6 font-sans">
      <div className="max-w-6xl mx-auto">
        {/* Header Banner */}
        <header className="mb-8 flex justify-between items-center bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">AttendAlert Dashboard</h1>
            <p className="text-sm text-gray-500">Real-time attendance tracking & early-warning analytics</p>
          </div>
          <div className="flex gap-4">
            <div className="bg-red-50 border border-red-200 px-4 py-2 rounded-lg text-center">
              <span className="block text-xl font-bold text-red-600">{criticalCount}</span>
              <span className="text-xs text-red-500 font-medium">Critical (&lt;65%)</span>
            </div>
            <div className="bg-yellow-50 border border-yellow-200 px-4 py-2 rounded-lg text-center">
              <span className="block text-xl font-bold text-yellow-600">{warningCount}</span>
              <span className="text-xs text-yellow-500 font-medium">Warning (65-74%)</span>
            </div>
          </div>
        </header>

        {/* Student Roster Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-100 flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-800">Student Attendance Roster</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 text-gray-600 text-xs uppercase tracking-wider">
                  <th className="p-4">Student Name</th>
                  <th className="p-4">Subject</th>
                  <th className="p-4">Attended / Total</th>
                  <th className="p-4">Percentage</th>
                  <th className="p-4">Risk Tier</th>
                  <th className="p-4">Recovery Action</th>
                  <th className="p-4 text-center">Quick Mark</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-sm">
                {students.map((student) => {
                  const badgeColor = 
                    student.riskTier === 'Critical' ? 'bg-red-100 text-red-700 border-red-200' :
                    student.riskTier === 'Warning' ? 'bg-yellow-100 text-yellow-700 border-yellow-200' :
                    'bg-green-100 text-green-700 border-green-200';

                  return (
                    <tr key={student.id} className="hover:bg-gray-50 transition-colors">
                      <td className="p-4 font-medium text-gray-900">{student.name}</td>
                      <td className="p-4 text-gray-600">{student.subject}</td>
                      <td className="p-4 text-gray-600">{student.attendedClasses} / {student.totalClasses}</td>
                      <td className="p-4 font-semibold text-gray-800">{student.percentage}%</td>
                      <td className="p-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${badgeColor}`}>
                          {student.riskTier}
                        </span>
                      </td>
                      <td className="p-4 text-gray-600">
                        {student.classesNeeded > 0 ? (
                          <span className="text-xs font-medium text-indigo-600">
                            Needs {student.classesNeeded} classes consecutively
                          </span>
                        ) : (
                          <span className="text-xs text-gray-400">Eligible (&ge;75%)</span>
                        )}
                      </td>
                      <td className="p-4 flex justify-center gap-2">
                        <button 
                          onClick={() => markAttendance(student.id, 'Present')}
                          className="px-2 py-1 bg-green-600 text-white rounded text-xs hover:bg-green-700">
                          Present
                        </button>
                        <button 
                          onClick={() => markAttendance(student.id, 'Absent')}
                          className="px-2 py-1 bg-red-600 text-white rounded text-xs hover:bg-red-700">
                          Absent
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
